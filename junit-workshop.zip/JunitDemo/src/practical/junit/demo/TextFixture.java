package practical.junit.demo;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TextFixture {
	
	static Person person;
	
	@BeforeClass
	public static void setUp() {
		person = new Person();
		// create connect with databases;
		System.out.println("Executed Create Person object 1  method");
	}
	
	@Before
	// it simple mean this method will execute each and every time when test method executed.
	public void updatePersonObject() {
		person.setName("vikas kumar");
		person.setEmail("Vikaskpro7@gmail.com");
		System.out.println("Executed before the test.");
	}
	
	@Test
	public void comparePersonObjectValuesTest() {
		assertEquals("vikas kumar", person.getName());
		System.out.println("Executed the test.");
	}
	
	@Test
	public void comparePerson2ObjectValuesTest() {
		assertEquals("Vikaskpro7@gmail.com", person.getEmail());
		System.out.println("Executed the test.");
	}
	
	@After
	public void resetValueToNull() {
		person.setName(null);
		person.setEmail(null);
		System.out.println("Executed after the test.");
	}
	
	@AfterClass
	public static void tearDown() {
		System.out.println("Executed delete Person method");
		// release the connection with the database.
		person = null;
	}
}
