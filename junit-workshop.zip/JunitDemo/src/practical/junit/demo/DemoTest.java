package practical.junit.demo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class DemoTest {

	
	@Test
	public void ComparningTwoStringTest() {
		String str = "hello this is demo test";
		System.out.println("test executed!");
		assertEquals("hello this is demo test", str);
		
	}
	
	
	public static void main(String[] args) {
	
	}

}
