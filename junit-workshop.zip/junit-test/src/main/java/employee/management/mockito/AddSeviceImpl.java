package employee.management.mockito;

public class AddSeviceImpl implements AddService {

	@Override
	public int add(int num1, int num2) {
		System.out.println("------- executed AddService implementation -----");
		return num1 + num2;
	}
}
