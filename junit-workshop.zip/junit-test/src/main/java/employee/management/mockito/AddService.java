package employee.management.mockito;

public interface AddService {
	public int add(int num1, int num2);
}
