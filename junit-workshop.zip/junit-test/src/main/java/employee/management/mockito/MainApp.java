package employee.management.mockito;

public class MainApp {

	public static void main(String[] args) {
		
		AddService addService = new AddSeviceImpl();
		
		CalcService calcService = new CalcService(addService);
		
		System.out.println(calcService.calc(10, 20));
		
	}

}
