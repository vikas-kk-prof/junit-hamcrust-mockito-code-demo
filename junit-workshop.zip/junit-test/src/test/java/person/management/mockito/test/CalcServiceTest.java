package person.management.mockito.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import employee.management.mockito.AddService;
import employee.management.mockito.CalcService;

public class CalcServiceTest {

	CalcService calcService;
	
	// label the service class as Mock so that 
	// mockito will create mock object of it.
	@Mock
	AddService addService;
	
	// Need to add this method so then it will create mock object.
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testCalcService() {
		System.out.println("--- test Calc service ---");
		
		calcService = new CalcService(addService);
		
		int num1 = 11;
		int num2 = 22;
		int excepted = 33;
		
		// defining the behavior of our mock object.
		when(addService.add(num1, num2)).thenReturn(excepted);
		
		// performing real operation
		int actual = calcService.calc(num1, num2);
		
		// comparing the both result. 
		assertEquals(excepted, actual);
	}
}
