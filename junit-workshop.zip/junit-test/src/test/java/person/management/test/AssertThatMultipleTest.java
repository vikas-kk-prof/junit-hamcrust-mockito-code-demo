package person.management.test;

import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.core.Every.everyItem;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import employee.management.Person;

public class AssertThatMultipleTest {

	@SuppressWarnings("deprecation")
	@Test
	public void CompareToString() {
		String str1 = "Hello";
		String str2 = "Hello";
		assertThat(str1, equalTo(str2));
	}
	
	
	@SuppressWarnings("deprecation")
	@Test
	public void CheckInstance() {
		Person person = new Person("abc", "abc@gmail.com");
		assertThat(person, instanceOf(Person.class));
		System.out.println();
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void checktextValueFromString() {
		assertThat("test", anyOf(is("testing"), containsString("est")));
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void checkListValuesTest() {
		List<Integer> list  = Arrays.asList(4, 5, 7);
		assertThat(list, hasSize(3));
		assertThat(list, contains(4, 5, 7));
		assertThat(list, everyItem(greaterThan(1)));
	}
}
