package person.management.test;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({CalculatorTest.class, PersonTestCases.class })
public class TestSuite {

	@BeforeClass
	public static void startMessage() {
		System.out.println("Running with Suite class.");
	}
}
