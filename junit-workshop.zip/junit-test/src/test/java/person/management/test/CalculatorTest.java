package person.management.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class CalculatorTest {
	private int a, b, c;
	
	@Before
	public void setUp() {
		a = 2;
		b = 0;
	}
	
	@Test(timeout = 5)
	public void showMessage(){
		System.out.println("Hello this message will run before CompareValue");
	}
	
	@Test
	public void CompareValues() {
		assertEquals(a, b);		
	}

	@Test(expected = ArithmeticException.class)
	public void valueDivideByZeroExceptionTest() {
		int value = a / b;
	}
}
