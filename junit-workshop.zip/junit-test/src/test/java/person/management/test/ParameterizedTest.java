package person.management.test;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import employee.management.Airthematic;

@RunWith(Parameterized.class)
public class ParameterizedTest {
	public int firstValue;
	public int secondValue;
	public int exceptedResult;
	public Airthematic airthematic;
	
	public ParameterizedTest(int firstValue, int secondValue, int exceptedResult) {
		this.firstValue = firstValue;
		this.secondValue = secondValue;
		this.exceptedResult = exceptedResult;
	}
	
	@Before
	public void initialize() {
		airthematic = new Airthematic();
	}
	
	@Parameters
	public static Collection<?>  input() {
		return Arrays.asList(new Object[][] {
			{ 1, 3, 4 },
			{ 30, 30, 60 },
			{ 11, 22, 33 },
			{ 56, 24, 80 },
		});
	}
	
	@Test
	public void multipleAritmaticTest() {
		assertEquals(exceptedResult, airthematic.sum(firstValue, secondValue));
	}
}
