package com.testing;

import org.junit.Test;

public class JunitMain {

	@Test
	public void JunitTest() {
		System.out.println("Executing junit test");
	}
	
	public static void main(String[] args) {
		
	}
}
